ITEM.name = "Example Cassette"
ITEM.desc = "An old rusty cassette containing music"
ITEM.model = "models/props_lab/box01b.mdl"
ITEM.music = "music/radio1.mp3"