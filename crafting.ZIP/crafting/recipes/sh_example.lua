CRAFTING.name = "Example"
CRAFTING.recipe = {
	{"Scrap Metal", 2}
}
CRAFTING.result = {"Example", 1}