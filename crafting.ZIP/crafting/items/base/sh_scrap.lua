ITEM.name = "Scrap Base"
ITEM.model = "models/gibs/wood_gib01a.mdl"
ITEM.category = "Scrap Materials"