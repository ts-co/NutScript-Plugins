ITEM.name = "Mushroom Seeds"
ITEM.foodDesc = "Seeds that can be used to plant mushrooms."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.mustCooked = true
ITEM.quantity = 1
ITEM.hungerAmount = 6000