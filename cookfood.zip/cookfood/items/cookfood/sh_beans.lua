ITEM.name = "Baked Beans"
ITEM.foodDesc = "A can of Baked Beans"
ITEM.model = "models/fallout 3/beans.mdl"
ITEM.quantity = 1
ITEM.hungerAmount = 4200