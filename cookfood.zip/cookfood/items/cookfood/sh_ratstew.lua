ITEM.name = "Rat Stew"
ITEM.foodDesc = "A bowl of Rat Stew"
ITEM.model = "models/fallout 3/rat_stew.mdl"
ITEM.mustCooked = true
ITEM.quantity = 1
ITEM.hungerAmount = 11200