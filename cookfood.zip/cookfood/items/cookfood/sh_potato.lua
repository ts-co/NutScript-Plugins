ITEM.name = "Potato"
ITEM.foodDesc = "A fresh Potato"
ITEM.model = "models/fallout 3/potato.mdl"
ITEM.quantity = 1
ITEM.hungerAmount = 4200