ITEM.name = "Shrimp"
ITEM.foodDesc = "A Piece of Shrimp"
ITEM.model = "models/gibs/antlion_gib_medium_2.mdl"
ITEM.mustCooked = true
ITEM.quantity = 3
ITEM.hungerAmount = 3000