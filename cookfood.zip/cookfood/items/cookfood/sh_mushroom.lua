ITEM.name = "Mushroom"
ITEM.foodDesc = "A fresh mushroom"
ITEM.model = "models/devcon/mrp/props/mushroom_2.mdl"
ITEM.quantity = 1
ITEM.hungerAmount = 4200