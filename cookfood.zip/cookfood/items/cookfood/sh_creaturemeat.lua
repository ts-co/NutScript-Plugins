ITEM.name = "Creature Meat"
ITEM.foodDesc = "Meat from the strange creatures of the Metro."
ITEM.model = "models/fallout 3/mole_meat.mdl"
ITEM.mustCooked = true
ITEM.quantity = 3
ITEM.hungerAmount = 1900
ITEM.price = 6