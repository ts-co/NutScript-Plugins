ITEM.name = "Chicken Noodle Soup"
ITEM.foodDesc = "A bowl of Chicken Noodle Soup"
ITEM.model = "models/fallout 3/ramen_noodels.mdl"
ITEM.mustCooked = true
ITEM.quantity = 1
ITEM.hungerAmount = 11200