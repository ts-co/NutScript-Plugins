ITEM.name = "Pork Stew"
ITEM.foodDesc = "A bowl of Pork and Mushroom Stew"
ITEM.model = "models/z-o-m-b-i-e/metro_2033/station_props/m33_plate_11.mdl"
ITEM.mustCooked = true
ITEM.quantity = 1
ITEM.hungerAmount = 140000