ITEM.name = "Rat"
ITEM.foodDesc = "A skewered rat"
ITEM.model = "models/fallout 3/iguana_stick.mdl"
ITEM.mustCooked = false
ITEM.quantity = 2
ITEM.hungerAmount = 2800