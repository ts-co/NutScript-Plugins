ITEM.name = "Human Flesh"
ITEM.foodDesc = "A strange looking slab of meat"
ITEM.model = "models/fallout 3/human_meat.mdl"
ITEM.quantity = 3
ITEM.hungerAmount = 980