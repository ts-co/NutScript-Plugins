ITEM.name = "Pork chop"
ITEM.foodDesc = "A Pork chop"
ITEM.model = "models/fallout 3/steak.mdl"
ITEM.mustCooked = true
ITEM.quantity = 3
ITEM.hungerAmount = 2800