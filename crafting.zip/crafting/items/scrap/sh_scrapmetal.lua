ITEM.name = "Scrap Metal"
ITEM.uniqueID = "Scrap Metal"
ITEM.model = "models/gibs/metal_gib5.mdl"