ITEM.name = "Example"
ITEM.uniqueID = "Example"
ITEM.model = "models/dav0r/hoverball.mdl"

ITEM.functions.use = {
	name = "Consume", --Name of the function, if this doesn't exist it'll use "use"
	tip = "Consume the item.", --Tip when hovering over the function
	icon = "icon16/cup.png", --Icon for the function
	onRun = function(item, data)
		nut.chat.send(item.player, "ic", "nom")
	end
}
