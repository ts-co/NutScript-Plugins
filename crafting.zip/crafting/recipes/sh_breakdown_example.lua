CRAFTING.name = "Example"
CRAFTING.category = "Breakdown"
CRAFTING.recipe = {
	{"Example", 1}
}
CRAFTING.result = {
	{"Scrap Metal", 2}
}