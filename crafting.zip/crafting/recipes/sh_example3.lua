CRAFTING.name = "Example3"
CRAFTING.category = "Thing"
CRAFTING.recipe = {
	{"Scrap Metal", 3}
}
CRAFTING.result = {"Example", 1}