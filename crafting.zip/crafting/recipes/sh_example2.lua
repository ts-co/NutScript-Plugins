CRAFTING.name = "Example 2"
CRAFTING.recipe = {
	{"Example", 1}
}
CRAFTING.result = {"Scrap Metal", 2}