CRAFTING.name = "Example2"
CRAFTING.category = "Thing"
CRAFTING.recipe = {
	{"Scrap Metal", 4}
}
CRAFTING.result = {
	{"Example", 1},
	{"Example", 1}
}