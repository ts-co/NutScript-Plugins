CRAFTING.name = "Example 2"
CRAFTING.category = "Breakdown"
CRAFTING.recipe = {
	{"Example", 1},
	{"Scrap Metal", 1}
}
CRAFTING.result = {"Scrap Metal", 2}