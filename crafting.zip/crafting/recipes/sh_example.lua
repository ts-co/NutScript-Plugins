CRAFTING.name = "Example"
CRAFTING.category = "Thing"
CRAFTING.recipe = {
	{"Scrap Metal", 2}
}
CRAFTING.result = {"Example", 1}