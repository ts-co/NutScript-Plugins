local PANEL = {}
	function PANEL:Init()
		self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())

		LocalPlayer().isCrafting = nil

		self.scroll = self:Add("DScrollPanel")
		self.scroll:Dock(LEFT)
		self.scroll:SetWide(self:GetParent():GetWide() * 0.25)
		self.scroll.Paint = function(panel, w, h)
			surface.SetDrawColor(0, 0, 0, 0)
			surface.DrawRect(0, 0, w, h)
		end

		self.itemInfo = self:Add("DPanel")
		self.itemInfo:Dock(FILL)
		self.itemInfo:DockMargin(6, 0, 0, 0)
		self.itemInfo:SetDrawBackground(false)

		self.title = self.itemInfo:Add("DLabel")
		self.title:Dock(TOP)
		self.title:SetFont("nutTitleFont")
		self.title:SetText("")
		self.title:SetAutoStretchVertical(true)

		self.requirementsTitle = self.itemInfo:Add("DLabel")
		self.requirementsTitle:Dock(TOP)
		self.requirementsTitle:SetFont("nutMediumFont")
		self.requirementsTitle:SetText("")
		self.requirementsTitle:SetAutoStretchVertical(true)

		self.model = self.itemInfo:Add("DModelPanel")
		self.model:Dock(FILL)
		self.model:SetLookAt(Vector(0, 0, 0))

		self:loadItems()
	end

	function PANEL:loadItems()
		self.scroll:Clear()
		self.title:SetText("")
		self.requirementsTitle:SetText("")
		self.model:SetModel("")

		self.chosen = nil
		self.requirements = nil

		self.inventory = LocalPlayer():getChar():getInv()

		local categories = {}

		for k, recipe in SortedPairsByMemberValue(nut.crafting.list, "category", true) do
			local itemTables = {}
			for _, resultItem in ipairs(recipe.result) do
				table.insert(itemTables, {nut.item.list[resultItem[1]], resultItem[2]})
			end

			if not table.HasValue(table.GetKeys(categories), recipe.category) then
				local category = self.scroll:Add("DCollapsibleCategory")
				category:Dock(TOP)
				category:SetLabel("")
				category:SetHeaderHeight(36)
				category.Paint = function(panel, w, h)
					surface.SetFont("nutBigFont")
					surface.SetTextColor(color_white)
					surface.SetTextPos(4, 0)
					surface.DrawText(recipe.category)
				end
				category:SetExpanded(true)

				categories[recipe.category] = category
			end

			local requirements = ""
			for k, requirement in ipairs(recipe.recipe) do
				if k > 1 then
					requirements = requirements..", "
				end
				requirements = requirements..requirement[1].." x"..requirement[2]
			end

			local button = categories[recipe.category]:Add("DButton")
			button:Dock(TOP)
			button:DockMargin(4, 4, 4, 4)
			button:SetTall(30)
			button:SetTextColor(Color(200, 200, 200))
			button:SetExpensiveShadow(1, Color(0, 0, 0))
			button:SetFont("nutSmallFont")
			button:SetText(recipe.name)
			button:SetMouseInputEnabled(true)
			button.DoClick = function(panel)
				self.chosen = {}
				for _, itemTable in ipairs(itemTables) do
					table.insert(self.chosen, {itemTable[1].uniqueID, itemTable[2]})
				end
				self.requirements = recipe.recipe

				--stop that yellow background from the category
				categories[recipe.category]:UnselectAll()

				if not LocalPlayer().isCrafting then
					for k, requirement in ipairs(recipe.recipe) do
						if self.inventory:getItemCount(requirement[1]) < requirement[2] then
							nut.util.notify("Insufficent crafting supplies!", LocalPlayer())
							break
						end

						if k == #recipe.recipe then
							LocalPlayer().isCrafting = self

							net.Start("nutCraftingUpdateInventory")
							net.WriteTable(self.chosen)
							net.WriteTable(self.requirements)
							net.SendToServer()
						end
					end
				end
			end
			button.Think = function(panel)
				if panel:IsHovered() then
					self.requirements = recipe.recipe
					self.model:SetModel(itemTables[1][1].model)
					self.title:SetText(recipe.name)
					self.requirementsTitle:SetText(requirements)
				end
			end
		end
	end
vgui.Register("nutCrafting", PANEL, "EditablePanel")

hook.Add("CreateMenuButtons", "nutCrafting", function(tabs)
	tabs["Crafting"] = function(panel)
		panel:Add("nutCrafting")
	end
end)

net.Receive("nutCraftingisCrafting", function()
	LocalPlayer().isCrafting.inventory = LocalPlayer():getChar():getInv()
	LocalPlayer().isCrafting = nil
end)