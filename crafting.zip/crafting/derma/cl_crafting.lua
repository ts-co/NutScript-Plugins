local PANEL = {}
	function PANEL:Init()
		self:SetSize(self:GetParent():GetWide(), self:GetParent():GetTall())

		LocalPlayer().isCrafting = nil

		self.scroll = self:Add("DScrollPanel")
		self.scroll:Dock(LEFT)
		self.scroll:SetWide(self:GetParent():GetWide() * 0.25)
		self.scroll.Paint = function(panel, w, h)
			surface.SetDrawColor(0, 0, 0, 200)
			surface.DrawRect(0, 0, w, h)
		end

		self.itemInfo = self:Add("DPanel")
		self.itemInfo:Dock(FILL)
		self.itemInfo:DockMargin(6, 0, 0, 0)
		self.itemInfo:SetDrawBackground(false)

		self.title = self.itemInfo:Add("DLabel")
		self.title:Dock(TOP)
		self.title:SetFont("nutTitleFont")
		self.title:SetText("")
		self.title:SetAutoStretchVertical(true)

		self.requirementsTitle = self.itemInfo:Add("DLabel")
		self.requirementsTitle:Dock(TOP)
		self.requirementsTitle:SetFont("nutMediumFont")
		self.requirementsTitle:SetText("")
		self.requirementsTitle:SetAutoStretchVertical(true)

		self.model = self.itemInfo:Add("DModelPanel")
		self.model:Dock(FILL)
		self.model:SetLookAt(Vector(0, 0, 0))

		self:loadItems()
	end

	function PANEL:loadItems()
		self.scroll:Clear()
		self.title:SetText("")
		self.requirementsTitle:SetText("")
		self.model:SetModel("")

		self.chosen = nil
		self.requirements = nil

		self.inventory = LocalPlayer():getChar():getInv()

		for k, recipe in pairs(nut.crafting.list) do
			local itemTable = nut.item.list[recipe.result[1]]

			local requirements = ""
			for k, requirement in ipairs(recipe.recipe) do
				if k > 1 then
					requirements = requirements..", "
				end
				requirements = requirements..requirement[1].." x"..requirement[2]
			end

			local button = self.scroll:Add("DButton")
			button:Dock(TOP)
			button:DockMargin(4, 4, 4, 4)
			button:SetTall(30)
			button:SetText(recipe.name)
			button:SetToolTip(requirements)
			button:SetMouseInputEnabled(true)
			button.DoClick = function(panel)
				self.model:SetModel(itemTable.model)
				self.chosen = itemTable.uniqueID
				self.requirements = recipe.recipe

				if not LocalPlayer().isCrafting then
					for k, requirement in ipairs(recipe.recipe) do
						if self.inventory:getItemCount(requirement[1]) < requirement[2] then
							nut.util.notify("Insufficent crafting supplies!", LocalPlayer())
							continue
						end

						if k == #recipe.recipe then
							LocalPlayer().isCrafting = self

							net.Start("nutCraftingUpdateInventory")
							net.WriteString(self.chosen)
							net.WriteInt(recipe.result[2], 16)
							net.WriteTable(self.requirements)
							net.SendToServer()
						end
					end
				end
			end
			button.Think = function(panel)
				if panel:IsHovered() then
					self.chosen = itemTable.uniqueID
					self.requirements = recipe.recipe

					self.model:SetModel(itemTable.model)
					self.title:SetText(recipe.name)
					self.requirementsTitle:SetText(requirements)
				end
			end
		end
	end
vgui.Register("nutCrafting", PANEL, "EditablePanel")

hook.Add("CreateMenuButtons", "nutCrafting", function(tabs)
	tabs["Crafting"] = function(panel)
		panel:Add("nutCrafting")
	end
end)

net.Receive("nutCraftingisCrafting", function()
	LocalPlayer().isCrafting.inventory = LocalPlayer():getChar():getInv()
	LocalPlayer().isCrafting = nil
end)