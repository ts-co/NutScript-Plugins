PLUGIN.name = "Body Parts"
PLUGIN.author = "Pilot"
PLUGIN.desc = "Base character system for customizing your character."

nut.util.include("sv_plugin.lua")
nut.util.include("cl_plugin.lua")

if (SERVER) then
	util.AddNetworkString("nutSaveBodypart") -- Client -> Server
	util.AddNetworkString("nutLoadBodypart") -- Server -> Client
	util.AddNetworkString("nutCreateBodypart") -- Server -> Client
	util.AddNetworkString("nutResetBodypart") -- Server -> Client

	nut.db.waitForTablesToLoad()
	:next(function()
		nut.db.query("ALTER TABLE nut_characters ADD COLUMN _bodypart TEXT")
		:catch(function() end)
	end)
end

nut.char.registerVar("bodypart", {
	field = "_bodypart",
	default = {},
	isLocal = true,
	index = 8,
	onValidate = function(value, data, client)
		if (value != nil) then
			if (type(value) != "table") then
				return false, "unknownError"
			end
		end
	end,
	onSet = function(character, key, model, bodygroup, skin, replace, exclude)
		if not nut.bodypart.get(key) then
			return false, "unknownError"
		end

		local client = character:getPlayer()

		if table.HasValue(table.GetKeys(character:getBodypart()), key) then
			if model == "" then
				model = character:getBodypart()[key]["default"]
			end
		end

		bodypart = {}
		bodypart["model"] = model
		bodypart["bodygroup"] = bodygroup
		bodypart["skin"] = skin
		bodypart["replace"] = replace
		bodypart["exclude"] = exclude

		netstream.Start(player.GetAll(), "bodypartData", character:getID(), key, bodypart)
	end,
	shouldDisplay = function(panel) return table.Count(nut.bodygroup.list) > 0 end
})

nut.command.add("fixbodies", {
	adminOnly = true,
	onRun = function(client, arguments)
		netstream.Start(player.GetAll(), "fixbodies")
	end
})

if (CLIENT) then
	netstream.Hook("bodypartData", function(id, key, value)
		local character = nut.char.loaded[id]

		if (character) then
			character.vars.bodypart = character.vars.bodypart or {}
			character:getBodypart()[key] = value
		end
	end)

	netstream.Hook("fixbodies", function()
		for _, client in ipairs(player.GetAll()) do
			client:removeBodyparts()
		end
	end)
end