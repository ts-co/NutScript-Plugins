local PANEL = {}

function PANEL:Init()
	self.title = self:addLabel("Customization")

	self.bodypart = {}

	self:setContext("bodypart", {})

	for _, bodypart in SortedPairsByMemberValue(nut.bodypart.list, "name") do
		if type(bodypart.default) != "table" then continue end
		if #bodypart.default == 0 then continue end

		local label = self:addLabel(bodypart.name)
		label:SetFont("nutCharSubTitleFont")

		self.bodypart[bodypart.name] = self:addBodypart(bodypart.name, bodypart.default)
	end
end

function PANEL:onDisplay()
	if #table.GetKeys(self.bodypart) == 0 then
		self:next()
	end
end

function PANEL:addBodypart(name, bodypart)
	local row = self:Add("nutCharacterBodypartRow")
	row:comboOptions(self, name, bodypart)
	row:Dock(TOP)

	return row
end

vgui.Register("nutCharacterBodypart", PANEL, "nutCharacterCreateStep")

PANEL = {}

function PANEL:Init()
	self.combo = self:Add("DComboBox")
	self.combo:Dock(FILL)
	self.combo:SetFont("nutCharSubTitleFont")
	self.combo:SetValue("Options")
	self.combo.Paint = function(this, w, h)
		nut.util.drawBlur(this)
		surface.SetDrawColor(0, 0, 0, 100)
		surface.DrawRect(0, 0, w, h)
	end
	self.combo:SetTextColor(color_white)
end

function PANEL:editModel(parent, model)
	local modelPanel = parent:getModelPanel()

	modelPanel:SetModel(model)
end

function PANEL:comboOptions(parent, name, bodypart)
	for k, bodypart in ipairs(bodypart) do
		self.combo:AddChoice("Option "..k)
	end

	local data = {}
	data["model"] = bodypart[1]
	data["bodygroup"] = {{0, 0}}
	data["skin"] = 0
	data["default"] = bodypart[1]

	self.combo:ChooseOption("Option 1", 1)
	parent:getContext("bodypart")[name] = data
	parent:setContext("bodypart", parent:getContext("bodypart"))

	self.combo.OnSelect = function(this, index, value)
		data["model"] = bodypart[index]
		data["bodygroup"] = {{0, 0}}
		data["skin"] = 0
		data["default"] = bodypart[index]

		parent:getContext("bodypart")[name] = data
		parent:setContext("bodypart", parent:getContext("bodypart"))

		self:editModel(parent, bodypart[index])
	end
end

vgui.Register("nutCharacterBodypartRow", PANEL, "DPanel")