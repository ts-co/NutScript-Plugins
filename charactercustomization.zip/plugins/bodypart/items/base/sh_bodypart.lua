ITEM.name = "Bodypart"
ITEM.desc = "A Bodypart Item Base."
ITEM.category = "Outfit"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.outfitCategory = "Head"
ITEM.outfitModel = "models/mossman.mdl"
ITEM.bodygroup = {{0, 0}}
ITEM.skin = 0
ITEM.replacement = false
ITEM.exclude = {}

-- Inventory drawing
if (CLIENT) then
	-- Draw camo if it is available.
	function ITEM:paintOver(item, w, h)
		if (item:getData("equip")) then
			surface.SetDrawColor(110, 255, 110, 100)
			surface.DrawRect(w - 14, h - 14, 8, 8)
		end
	end
end

function ITEM:wearOutfit(client, isForLoadout)
	self.player:createBodypart(self.outfitCategory, self.outfitModel, self.bodygroup, self.skin, self.replacement, self.exclude)

	self:call("onWear", client, nil, isForLoadout)
end

function ITEM:removeOutfit(client)
	local character = client:getChar()

	self:setData("equip", nil)

	client:resetBodypart(self.outfitCategory, false)

	self:call("onTakeOff", client)
end



ITEM:hook("drop", function(item)
	if (item:getData("equip")) then
		item:removeOutfit(item.player)
	end
end)

ITEM.functions.Equip = {
	name = "Equip",
	tip = "equipTip",
	icon = "icon16/tick.png",
	onRun = function(item)
		local char = item.player:getChar()
		local items = char:getInv():getItems()

		for id, other in pairs(items) do
			if (
				item ~= other and
				item.outfitCategory == other.outfitCategory and
				other:getData("equip")
			) then
				item.player:notifyLocalized("sameOutfitCategory")
				return false
			end
		end

		item:setData("equip", true)
		item:wearOutfit(item.player, false)

		return false
	end,
	onCanRun = function(item)
		return not IsValid(item.entity) and item:getData("equip") ~= true
	end
}

ITEM.functions.Unequip = {
	name = "Unequip",
	tip = "equipTip",
	icon = "icon16/cross.png",
	onRun = function(item)
		item:removeOutfit(item.player)
		return false
	end,
	onCanRun = function(item)
		return not IsValid(item.entity) and item:getData("equip") == true
	end
}

function ITEM:onCanBeTransfered(oldInventory, newInventory)
	if (newInventory and self:getData("equip")) then
		return false
	end

	return true
end

function ITEM:onLoadout()
	if (self:getData("equip")) then
		self:wearOutfit(self.player, true)
	end
end

function ITEM:onRemoved()
	local inv = nut.item.inventories[self.invID]
	if (IsValid(receiver) and receiver:IsPlayer()) then
		if (self:getData("equip")) then
			self:removeOutfit(receiver)
		end
	end
end

function ITEM:onWear(isFirstTime)
end

function ITEM:onTakeOff()
end
