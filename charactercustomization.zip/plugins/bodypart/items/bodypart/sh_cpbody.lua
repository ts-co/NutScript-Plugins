ITEM.name = "Combine Body"
ITEM.desc = "Really nice armor cool!"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.outfitCategory = "Body"
ITEM.outfitModel = "models/police.mdl"
ITEM.replacement = true
ITEM.exclude = {"ValveBiped.Bip01_Head1"}