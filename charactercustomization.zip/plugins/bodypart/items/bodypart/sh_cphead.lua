ITEM.name = "Combine Helmet"
ITEM.desc = "Really nice helmet cool!"
ITEM.model = "models/props_c17/BriefCase001a.mdl"
ITEM.outfitCategory = "Head"
ITEM.outfitModel = "models/police.mdl"
ITEM.replacement = true
ITEM.exclude = {"+", "ValveBiped.Bip01_Head1"}