nut.bodypart = nut.bodypart or {}
nut.bodypart.list = nut.bodypart.list or {}

function nut.bodypart.loadFromDir(directory)
	for k, v in ipairs(file.Find(directory.."/*.lua", "LUA")) do
		local niceName = v:sub(4, -5)

		BODYPART = nut.bodypart.list[niceName] or {}
			nut.util.include(directory.."/"..v)

			if (PLUGIN) then
				BODYPART.plugin = PLUGIN.uniqueID
			end

			BODYPART.name = BODYPART.name or "Unknown"
			BODYPART.default = BODYPART.default or {}
			BODYPART.models = BODYPART.models or {}

			if #BODYPART.default > 0 then
				for _, model in ipairs(BODYPART.default) do
					if not table.HasValue(BODYPART.models, model) then
						table.insert(BODYPART.models, model)
					end
				end
			end

			nut.bodypart.list[niceName] = BODYPART
		BODYPART = nil
	end
end

function nut.bodypart.get(name)
	for _, bodypart in pairs(nut.bodypart.list) do
		if nut.util.stringMatches(name, bodypart.name) then
			return bodypart
		end
	end
end

--[[-------------------------------------------------------------------------
playerMeta
---------------------------------------------------------------------------]]
local playerMeta = FindMetaTable("Player")

function playerMeta:getBodypartEntity(name)
	if not self:getChar():getBodypart()[name] then return end
	
	--[[
	for _, entity in ipairs(ents.FindByModel(self:getBodypart()[name])) do
		if entity:GetParent() == client then
			return entity
		end
	end
	--]]

	for _, child in ipairs(self:GetChildren()) do
		if child:GetClass() == "class C_PhysPropClientside" then
			if child:GetNetworkedString("name") == name then
				return child
			end
		end
	end
end


function playerMeta:removeBodyparts()
	for _, child in ipairs(self:GetChildren()) do
		if child:GetClass() == "class C_PhysPropClientside" then
			child:Remove()
		end
	end

	for i=0, self:GetBoneCount() - 1 do
		self:ManipulateBoneScale(i, Vector(1, 1, 1))
	end
end

function playerMeta:saveBodypart(name, model, bodygroup, skin, replace, exclude)
	bodygroup = bodygroup or {
		{0, 0}
	}
	skin = skin or 0

	replace = replace or false
	exclude = exclude or {}

	net.Start("nutSaveBodypart")
	net.WriteEntity(self)
	net.WriteString(nut.bodypart.get(name).name)
	net.WriteString(model)
	net.WriteTable(bodygroup)
	net.WriteInt(skin, 6)
	net.WriteBool(replace)
	net.WriteTable(exclude)
	net.SendToServer()
end

function playerMeta:createBodypart(name, model, bodygroup, skin, replace, exclude)
	bodygroup = bodygroup or {
		{0, 0}
	}
	skin = skin or 0

	if (CLIENT) then
		if not nut.bodypart.get(name) then return end

		if not table.HasValue(nut.bodypart.get(name).models, model) then
			Error("Error: Model ("..model..") does not exist in bodypart list ("..nut.bodypart.get(name).name..")\n")
		end

		local character = self:getChar()

		-- Remove any pre-existing bodyparts
		if character:getBodypart()[name] then
			self:resetBodypart(name)
		end

		for _, client in ipairs(player.GetAll()) do
			bodypart = ents.CreateClientProp()
			bodypart:SetModel(model)
			bodypart:SetPos(self:GetPos())
			bodypart:SetParent(self)
			bodypart:SetNetworkedString("name", name)

			for _, group in ipairs(bodygroup) do
				bodypart:SetBodygroup(group[1], group[2])
			end

			bodypart:SetSkin(skin)

			bodypart:AddEffects(bit.bor(EF_BONEMERGE, EF_BONEMERGE_FASTCULL, EF_PARENT_ANIMATES))
			bodypart:Spawn()

			bodypart:SetupBones()

			if replace then
				for i=0, bodypart:GetBoneCount() - 1 do
					local bone = self:LookupBone(bodypart:GetBoneName(i))

					if exclude then
						if exclude[1] == "+" then
							if not table.HasValue(exclude, bodypart:GetBoneName(i)) then
								bodypart:ManipulateBoneScale(i, Vector(0.1, 0.1, 0.1))
								continue
							end
						else
							if table.HasValue(exclude, bodypart:GetBoneName(i)) then
								bodypart:ManipulateBoneScale(i, Vector(0.1, 0.1, 0.1))
								continue
							end
						end
					end

					if bone then
						self:ManipulateBoneScale(bone, Vector(0.1, 0.1, 0.1))
					end

					bodypart:ManipulateBoneScale(i, Vector(10, 10, 10))
				end
			end

			--[[
			if replace then
				for i=0, bodypart:GetBoneCount() - 1 do
					local bone = self:LookupBone(bodypart:GetBoneName(i))

					if exclude then
						if exclude[1] == "+" then
							if not table.HasValue(exclude, bodypart:GetBoneName(i)) then
								bodypart:ManipulateBoneScale(i, Vector(0.1, 0.1, 0.1))
								continue
							end
						else
							if table.HasValue(exclude, bodypart:GetBoneName(i)) then
								bodypart:ManipulateBoneScale(i, Vector(0.1, 0.1, 0.1))
								continue
							end
						end
					end

					if bone then
						self:ManipulateBoneScale(bone, Vector(0.1, 0.1, 0.1))
					end

					bodypart:ManipulateBoneScale(i, Vector(10, 10, 10))
				end
			end
			--]]
		end

		self:saveBodypart(nut.bodypart.get(name).name, model, bodygroup, skin, replace, exclude)
	else
		net.Start("nutCreateBodypart")
		net.WriteEntity(self)
		net.WriteString(name)
		net.WriteString(model)
		net.WriteTable(bodygroup)
		net.WriteInt(skin, 6)
		net.WriteBool(replace)
		net.WriteTable(exclude)
		net.Broadcast()
	end
end

function playerMeta:resetBodypart(name)
	if (CLIENT) then
		if not istable(self:getChar():getBodypart()[name]) then return end
		
		for _, client in ipairs(player.GetAll()) do
			if not self:getChar():getBodypart()[name]["default"] then
				if IsValid(client:getBodypartEntity(name)) then
					client:getBodypartEntity(name):Remove()
				end
			end

			if istable(self:getChar():getBodypart()[name]["exclude"]) then
				if #self:getChar():getBodypart()[name]["exclude"] > 0 then
					local exclude = self:getChar():getBodypart()[name]["exclude"]

					for i=0, self:GetBoneCount() - 1 do
						if exclude[1] == "+" then
							if not table.HasValue(exclude, self:GetBoneName(i)) then
								continue
							end
						elseif table.HasValue(exclude, self:GetBoneName(i)) then
							continue
						end

						self:ManipulateBoneScale(i, Vector(1, 1, 1)) 
					end
				end
			end

			self:saveBodypart(nut.bodypart.get(name).name, "")
		end
	else
		net.Start("nutResetBodypart")
		net.WriteEntity(self)
		net.WriteString(name)
		net.Broadcast()
	end
end

if (SERVER) then
	net.Receive("nutSaveBodypart", function()
		local client = net.ReadEntity()
		local name = net.ReadString()
		local model = net.ReadString()
		local bodygroup = net.ReadTable()
		local skin = net.ReadInt(6)
		local replace = net.ReadBool()
		local exclude = net.ReadTable()

		client:getChar():setBodypart(name, model, bodygroup, skin, replace, exclude)
	end)
else
	net.Receive("nutCreateBodypart", function()
		local client = net.ReadEntity()
		local name = net.ReadString()
		local model = net.ReadString()
		local bodygroup = net.ReadTable()
		local skin = net.ReadInt(6)
		local replace = net.ReadBool()
		local exclude = net.ReadTable()

		client:createBodypart(name, model, bodygroup, skin, replace, exclude)
	end)

	net.Receive("nutResetBodypart", function()
		local client = net.ReadEntity()
		local name = net.ReadString()

		client:resetBodypart(name)
	end)
end

hook.Add("DoPluginIncludes", "nutBodypartLib", function(path)
	nut.bodypart.loadFromDir(path.."/bodypart")
end)