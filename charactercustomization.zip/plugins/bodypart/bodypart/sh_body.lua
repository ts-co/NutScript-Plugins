BODYPART.name = "Body"

BODYPART.models = {
	"models/police.mdl"
}