BODYPART.name = "Head"

BODYPART.models = {
	"models/police.mdl"
}